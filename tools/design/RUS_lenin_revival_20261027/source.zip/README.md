# [KR] 列宁复活线（独立彩蛋包）v0.1.0

这是一个**完全独立**的 HOI4 / Kaiserreich 内容包：新增一棵 62 个国策的独立国策树、一条彩蛋事件链、一个开启决议、14 个新国家精神，以及简中/英文本地化。

> **本包没有修改原模组的任何文件。** 所有内容都是新增文件，可单独启用，也可由项目组直接并入主模组。

---

## 一、它怎么运作

1. 开局选择 **俄罗斯（RUS）**。
2. 在决议面板打开新分类 **“列宁复活线”**，点击 **“是否启用彩蛋事件/线路”**。
3. 一天后触发事件 **“熟悉的身影”**：
   - **A**：是斯大林同志，他也回来了（无变化，事件结束）。
   - **B**：那是——弗拉基米尔·伊里奇·乌里扬诺夫？！（**载入独立国策树**）。
4. 选择 B 后，游戏通过 `load_focus_tree` 把 RUS 的国策树整体切换为 `RUS_lenin_revival_focus`（原 `Russia_Focus` 会被替换，原有国策进度不保留；这是“独立树”必须付出的代价）。
5. 新树从 **“久有凌云志，重上乌拉尔”** 开始，依次经历：布尔什维克回归 → 党内路线争论 → 更名 RSFSR 并发动内战 → 击败社会革命党 → 党建/国家重建 → 计划经济。

---

## 二、文件清单

```
RUS_Lenin_Revival/
├─ descriptor.mod
├─ common/
│  ├─ national_focus/00_RUS_lenin_revival_focus.txt      # 62 个国策的独立 focus_tree
│  ├─ ideas/00_RUS_lenin_revival_ideas.txt               # 14 个新国家精神
│  └─ decisions/
│     ├─ categories/00_RUS_lenin_revival_categories.txt  # 决议分类
│     └─ 00_RUS_lenin_revival_decisions.txt              # 彩蛋开关决议
├─ events/00_RUS_lenin_revival_events.txt                # 熟悉的身影 / 内战 / 社革落败 / 经济胜利
└─ localisation/
   ├─ simp_chinese/00_RUS_lenin_revival_l_simp_chinese.yml
   └─ english/00_RUS_lenin_revival_l_english.yml
RUS_Lenin_Revival.mod                                     # 独立子模组描述文件
README.md
```

树 ID：`RUS_lenin_revival_focus`
事件命名空间：`RUS_lenin_revival`
所有国策/理念/决议 ID 前缀：`RUS_LR_`

---

## 三、安装（作为独立子模组）

1. 把 `RUS_Lenin_Revival` 文件夹复制到：
   `C:\Users\<你>\Documents\Paradox Interactive\Hearts of Iron IV\mod\`
2. 把 `RUS_Lenin_Revival.mod` 复制到同一层 `mod\` 目录。
3. 启动器里同时启用：
   - Kaiserreich
   - `[KR] 多么幼稚的幻想，但是斯大林 - 测试版`
   - 本包（建议排在主模组之后）
4. 进入游戏，选俄罗斯，按上面的流程测试。

> 如果项目组要把内容并入主模组，直接复制 `common/`、`events/`、`localisation/` 下对应文件即可；没有任何路径或文件名与原文件冲突。

---

## 四、调试命令

控制台可用：

```
event RUS_lenin_revival.1     # 直接触发“熟悉的身影”
event RUS_lenin_revival.20    # 直接触发内战事件
event RUS_lenin_revival.21    # 直接触发社革落败
event RUS_lenin_revival.22    # 直接触发经济胜利
```

选 B 之后如果树没有立刻出现，保存并读档一次，或确认 `load_focus_tree` 已生效。

---

## 五、从图纸到脚本的对应关系

- 图纸共 64 个节点，其中 **2 个是椭圆注释**：
  - “更名为俄罗斯苏维埃社会主义共和国，并发动内战” → 实现为 **36 号国策“革命从地狱中回来了”的完成效果**（`set_cosmetic_tag = RUS_sov` + 触发内战事件）。
  - “需要《宣告社会革命党的落败》” → 实现为 **62 号国策的前置条件**（`prerequisite = { focus = RUS_LR_declare_sr_defeat }`）。
- 图纸中有 4 条连线指向已删除的旧节点，按端点坐标还原为：
  - 14 → 18（布尔什维克与社会革命党 → 布哈林的回归）
  - 16 → 24（劝解季诺维也夫与加米涅夫 → 批评托洛茨基）
  - 20 → 28（无产阶级专政不可动摇 → 吸取十月革命的教训）
  - 22 → 26（批判修正主义思想 → 农民与工人）
- 图纸中 **107“建立国家计划委员会”没有连线**。按位置（84 正下方）实现为 **84 → 107**。如果设计本意是 62 或 59 直接解锁计划经济，只需改 `RUS_LR_establish_gosplan` 的 `prerequisite`。
- 图纸右侧的战后/计划经济两大簇在垂直方向整体下移到 59 之后（x 坐标保持原图纸的绝对列），否则会出现一条横跨整棵树的超长前置线。
- 图纸里“革命胜利之后 / 恢复中央人民委员会 / 恢复党的代表大会制度 / 结束组织混乱”四支在 84 汇合；脚本里 84 需要 **79、81、99、101 四个前置全部完成**，与图纸一致。

---

## 六、需要项目组确认/替换的地方

1. **内战意识形态**：事件 `RUS_lenin_revival.20` 里用的是
   `start_civil_war = { ideology = social_democrat size = 0.35 }`。
   如果社革党在 KR 里对应的是别的意识形态组（例如 `radical_socialist`），改这一行即可。
2. **列宁作为领袖**：当前模组没有 `RUS_vladimir_lenin` 角色/头像，所以本包**没有**把列宁加为国家领袖，只加了“列宁归来”国家精神。若要加领袖，需要补角色定义与头像 GFX。
3. **图标**：62 个国策全部复用 KR/原版已有的通用图标（`GFX_goal_generic_*`），国家精神复用 `GFX_idea_generic_*`。等美术资源到位后替换 `icon =` 与 `picture =` 即可。
4. **数值平衡**：所有 `add_political_power` / `add_stability` / `add_war_support` / 理念修正都是首版占位值，未做平衡。
5. **原树进度**：`load_focus_tree` 会替换原 `Russia_Focus`，已完成国策不会带入新树。如果希望保留原树进度，需要改成 `shared_focus` 方案（但那必须在原树文件里加引用，违背“零改动”要求）。

---

## 七、兼容性

- 游戏版本：1.19.3.0（与主模组 `supported_version` 一致）
- 依赖：Kaiserreich、`[KR] 多么幼稚的幻想，但是斯大林`
- 未使用任何 DLC 限定内容；`start_civil_war`、`load_focus_tree` 均为原版效果。
