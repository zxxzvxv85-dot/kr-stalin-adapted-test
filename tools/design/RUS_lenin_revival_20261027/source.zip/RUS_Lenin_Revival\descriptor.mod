name="[KR] 列宁复活线（独立彩蛋包）"
version="0.1.0"
supported_version="1.19.3.0"
tags={
	"Alternative History"
	"Events"
	"National Focuses"
}
